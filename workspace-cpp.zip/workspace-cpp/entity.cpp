#pragma once

#include "vec3.cpp"

struct player {
	vec3 pos;
	double yaw;
	double pitch;

	player() {
		this->pos = vec3(0.0, 0.0, 0.0);
		this->yaw = 0.0;
		this->pitch = 0.0;
	}

	player(vec3 &_pos) {
		this->pos = _pos;
		this->yaw = 0.0;
		this->pitch = 0.0;
	}

	player(vec3 &_pos, double _yaw, double _pitch) {
		this->pos = _pos;
		this->yaw = _yaw;
		this->pitch = _pitch;
	}
};