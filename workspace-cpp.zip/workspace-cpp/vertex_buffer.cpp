#pragma once
#include <GL/glew.h>

#include "vec3.cpp"

struct VertexBuffer {
    VertexBuffer(vec3 *data, int numVerticies) {
        glGenVertexArrays(1, &vao);
        glBindVertexArray(vao);
        
        glGenBuffers(1, &bufferID);
        glBindBuffer(GL_ARRAY_BUFFER, bufferID);
        glBufferData(GL_ARRAY_BUFFER, numVerticies * sizeof(vec3), data, GL_STATIC_DRAW);
    
        glEnableVertexAttribArray(0);
	    glVertexAttribPointer(0, 3, GL_FLOAT, false, sizeof(vec3), offsetof(struct vec3, d));
    
        glBindVertexArray(0);
    }

    virtual ~VertexBuffer() {
        glDeleteBuffers(1, &bufferID);
    }

    void bind() {
        glBindVertexArray(vao);
    }

    void unbind() {
        glBindVertexArray(0);
    }

private:
 GLuint bufferID;
 GLuint vao;

};