#pragma once
#include <string>
#include <math.h>

using std::string;

//Simple math utility struct using 3 doubles as an array representing a 3-dimensional vector
struct vec3 {

	// Holds the three components of this vec3
	double d[3];

	// Initializes a vec3 from zero values => (0, 0, 0)
	vec3() {
		d[0] = 0.0;
		d[1] = 0.0;
		d[2] = 0.0;
	}

	// Initializes a vec3 from one value => (a, a, a)
	vec3(const double a) {
		d[0] = a;
		d[1] = a;
		d[2] = a;
	}

	// Initializes a vec3 from three values => (x, y, z)
	vec3(const double x, const double y, const double z) {
		d[0] = x;
		d[1] = y;
		d[2] = z;
	}

	// Initializes a vec3 from one vec3 v => (v.x, v.y, v.z)
	vec3(const vec3 &v) {
		d[0] = v.d[0];
		d[1] = v.d[1];
		d[2] = v.d[2];
	}

	// Returns the string representation of this
	inline string toString() {
		return "(" + std::to_string(this->d[0]) +
              ", " + std::to_string(this->d[1]) + 
              ", " + std::to_string(this->d[2]) + ")";
	}
	
	// Returns if the vec3 v equals to this
	inline bool operator = (const vec3 v) {
		return this->d[0] == v.d[0] && this->d[1] == v.d[1] && this->d[2] == v.d[2];
	}

	// --------------------------------------------------------------------------------------------------------------------------------


	// Returns the sum of this and the vec3 (a, a, a)
	inline vec3 operator + (double a) {
		return vec3(this->d[0] + a,
					this->d[1] + a,
					this->d[2] + a);
	}

	// Returns the difference of this and the vec3 (a, a, a)
	inline vec3 operator - (double a) {
		return vec3(this->d[0] - a,
					this->d[1] - a,
					this->d[2] - a);
	}

	// Returns the product of this and the double a
	inline vec3 operator * (double a) {
		return vec3(this->d[0] * a,
					this->d[1] * a,
					this->d[2] * a);
	}

	// Returns the quotient of this and the double a
	inline vec3 operator / (double a) {
		return vec3(this->d[0] / a,
					this->d[1] / a,
					this->d[2] / a);
	}


	// --------------------------------------------------------------------------------------------------------------------------------


	// Returns the sum of this and the vec3 v
	inline vec3 operator + (vec3 &v) {
		return vec3(this->d[0] + v.d[0],
					this->d[1] + v.d[1],
					this->d[2] + v.d[2]);
	}

	// Returns the difference of this and the vec3 v
	inline vec3 operator - (vec3 &v) {
		return vec3(this->d[0] - v.d[0],
					this->d[1] - v.d[1],
					this->d[2] - v.d[2]);
	}

	// Returns the product of this and the vec3 v (componentwise)
	inline vec3 operator * (vec3 &v) {
		return vec3(this->d[0] * v.d[0],
					this->d[1] * v.d[1],
					this->d[2] * v.d[2]);
	}

	// Returns the quotient of this and the vec3 v (componentwise)
	inline vec3 operator / (vec3 &v) {
		return vec3(this->d[0] / v.d[0],
					this->d[1] / v.d[1],
					this->d[2] / v.d[2]);
	}


	// --------------------------------------------------------------------------------------------------------------------------------


	// Adds the vec3 (a, a, a) to this
	inline void operator += (double a) {
		this->d[0] += a;
		this->d[1] += a;
		this->d[2] += a;
	}

	// Subtracts the vec3 (a, a, a) from this
	inline void operator -= (double a) {
		this->d[0] -= a;
		this->d[1] -= a;
		this->d[2] -= a;
	}

	// Multiplies this by the double a
	inline void operator *= (double a) {
		this->d[0] *= a;
		this->d[1] *= a;
		this->d[2] *= a;
	}

	// Divides this by the double a
	inline void operator /= (double a) {
		this->d[0] /= a;
		this->d[1] /= a;
		this->d[2] /= a;
	}


	// --------------------------------------------------------------------------------------------------------------------------------


	// Adds the vec3 v to this
	inline void operator += (vec3 &v) {
		this->d[0] += v.d[0];
		this->d[1] += v.d[1];
		this->d[2] += v.d[2];
	}

	// Subtracts the vec3 v from this
	inline void operator -= (vec3 &v) {
		this->d[0] -= v.d[0];
		this->d[1] -= v.d[1];
		this->d[2] -= v.d[2];
	}

	// Multiplies this by the vec3 v (componentwise)
	inline void operator *= (vec3 &v) {
		this->d[0] *= v.d[0];
		this->d[1] *= v.d[1];
		this->d[2] *= v.d[2];
	}

	// Divides this by the vec3 v (componentwise)
	inline void operator /= (vec3 &v) {
		this->d[0] /= v.d[0];
		this->d[1] /= v.d[1];
		this->d[2] /= v.d[2];
	}


	// --------------------------------------------------------------------------------------------------------------------------------


	// Returns the length
	inline double length() {
		double x = this->d[0];
		double y = this->d[1];
		double z = this->d[2];
		return sqrt(x * x + y * y + z * z);
	}

	// Returns the squared length
	inline double lengthSquared() {
        double x = this->d[0];
		double y = this->d[1];
		double z = this->d[2];
		return x * x + y * y + z * z;
	}

    // Returns the distance between vec3 v and this
	inline double distance(vec3 &v) {
		double dx = this->d[0] - v.d[0];
		double dy = this->d[1] - v.d[1];
		double dz = this->d[2] - v.d[2];
		return sqrt(dx * dx + dy * dy + dz * dz);
	}

    // Returns the squared distance between vec3 v and this
	inline double distanceSquared(vec3 &v) {
		double dx = this->d[0] - v.d[0];
		double dy = this->d[1] - v.d[1];
		double dz = this->d[2] - v.d[2];
		return dx * dx + dy * dy + dz * dz;
	}


    // --------------------------------------------------------------------------------------------------------------------------------


    // Returns the dot product of vec3 v and this
    inline double dot(vec3 &v) {
        return this->d[0] * v.d[0] + this->d[1] * v.d[1] + this->d[2] * v.d[2];
    }

    // Returns the normalized vector
    inline vec3 normalized() {
        double l = length();
        return vec3(this->d[0] / l,
                    this->d[1] / l,
                    this->d[2] / l);
    }

    // Normalizes the vector
    inline void normalize() {
        double l = length();
        this->d[0] /= l;
        this->d[1] /= l;
        this->d[2] /= l;
    }
};

