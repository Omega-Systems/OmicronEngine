#include <iostream>
#include <math.h>
#include <chrono>

#include "entity.cpp"
#include "vertex_buffer.cpp"

#define GLEW_STATIC
#include <GL/glew.h>
#define SDL_MAIN_HANDLED

#ifdef _WIN32
#include <SDL.h>
#pragma comment(lib, "SDL2.lib")
#pragma comment(lib, "glew32s.lib")
#pragma comment(lib, "opengl32.lib")
#else
#include <SDL2/SDL.h>
#endif

#define WIDTH 800
#define HEIGHT 450

using std::cout;
using std::endl;
using std::string;

bool walkForward = false;
bool walkBackward = false;
bool walkLeft = false;
bool walkRight = false;

// main rendering, color clearing and buffer swapping here
void render(SDL_Window *window)
{
	glClearColor(0.0f, 0.5f, 0.5f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(1.0f, 0.0f, 0.0f);
	glDrawArrays(GL_TRIANGLES, 0, 3);

	//=====================================
	/*
	glColor3f(1.0f, 0.0f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(1.0f, 0.0f);
	glVertex2f(1.0f, 1.0f);
	glEnd();
	*/
	//=====================================
	//       ^
	//       |
	//       |
	//  Bad Code here

	SDL_GL_SwapWindow(window);
}

int main(int argc, char **argv)
{
	// Initializes the window 
	SDL_Window *window;
	SDL_Init(SDL_INIT_EVERYTHING);

	// Defines the frame pixel attributes and enables double buffering
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE, 32);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

	window = SDL_CreateWindow("OmegaSystems - Engine Test", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, SDL_WINDOW_OPENGL);
	
	// Initializes the GL context
	SDL_GLContext glContext = SDL_GL_CreateContext(window);

	// Initializes GLU (OpenGL extensions (1.1+) loader)
	GLenum err = glewInit();
	if(err != GLEW_OK) {cout << "Error loading graphics driver: "<< glewGetErrorString(err) << endl; return -1;}

	cout << "OpenGL-Version: " << glGetString(GL_VERSION) << endl;

	vec3 verticies[] = {
		vec3(-0.5f, -0.5f, 0.0f),
		vec3(0.0f, 0.5f, 0.0f),
		vec3(0.5f, -0.5f, 0.0f)
	};
	int numVerticies = 3;

	VertexBuffer buffer(verticies, 3);
	buffer.bind();

	// Initializes varaibles for time and tick managment
	auto lastTick = std::chrono::high_resolution_clock::now();
	auto thisTick = std::chrono::high_resolution_clock::now();
	double deltaTime;
	int ticks = 0;

	// Starts the main loop
	bool isRunning = true;
	while (isRunning) {
		// Calculates delta time and increments ticks counter
		thisTick = std::chrono::high_resolution_clock::now();
		deltaTime = std::chrono::duration_cast<std::chrono::microseconds>(thisTick - lastTick).count() / 1'000'000;
		lastTick = thisTick;
		ticks++;

		//cout << "DeltaTime (in ms): " << deltaTime / 1000 << endl;
		
		render(window);

		// Handles events
		SDL_Event event;
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT: 
				isRunning = false;
				break;
			case SDL_KEYDOWN:
				cout << event.key.keysym.sym << endl;
				break;
			case SDL_KEYUP:
				break;
			default: break;
			}
		}
	}

	return 0;
}